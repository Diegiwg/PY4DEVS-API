# PY4DEVS API
- TRABALHO EM PROGRESSO - V0.1.0 WIP

## Sobre

- A biblioteca *py4devs* tem por objetivo fornecer um meio simples de utilizar as incriveis ferramentas desenvolvidas pela equipe 4DEVS.COM.BR diretamente nos scripts/projetos python.

## Estado Atual

- A biblioteca está em desenvolvimento há apenas um dia.
- A maioria das ferramentas de geração de dados já possuem cobertura.